//
//  XMLElements.swift
//  Constitution
//
//  Created by apple on 9/18/21.
//

import Foundation
import SwiftyXMLParser
struct XMLElement {
    
    var id: String
    var title: String
    var parttitle: String
    var subtitle: String
    var labeltitle: String
    var patharray: [XMLSubscriptType]
    var nodetype : Int
    var content : String
    
    
    init(id: String,title:String, parttitle: String, subtitle: String, labeltitle: String, nodetype:Int) {
        

        self.id = id
        self.title = title;
        self.parttitle = parttitle
        self.subtitle = subtitle
        self.labeltitle = labeltitle
        self.patharray = ["Constitution","section"]
        self.nodetype = nodetype
        self.content = ""
    }
}

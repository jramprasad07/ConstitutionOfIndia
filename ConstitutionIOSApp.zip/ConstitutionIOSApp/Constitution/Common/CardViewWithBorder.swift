//
//  CardViewWithBorder.swift
//  Constitution
//
//  Created by macmini on 30/10/21.
//

import UIKit

@IBDesignable class CardViewWithBorder: UIView {
    
    @IBInspectable var shadowWidth: Int = 0
    @IBInspectable var shadowHeight: Int = 0
    @IBInspectable var shadowOpacity: Float = 0.2
    @IBInspectable var cornerRadius: CGFloat = 10
    @IBInspectable var shadowColor: UIColor = .black
    @IBInspectable var borderColor: UIColor = UIColor(red: 56.0/255.0, green: 118.0/255.0, blue: 242.0/255.0, alpha: 1.0)
    
    override func layoutSubviews() {
        layer.cornerRadius = cornerRadius
        layer.shadowColor = shadowColor.cgColor
        layer.shadowOpacity = shadowOpacity
        layer.borderWidth = 1.0
        layer.borderColor = borderColor.cgColor
        
        let path = UIBezierPath(roundedRect: bounds,cornerRadius: cornerRadius)
        
        layer.shadowPath = path.cgPath
        layer.shadowOffset = CGSize(width: shadowWidth, height: shadowHeight)
    }

}



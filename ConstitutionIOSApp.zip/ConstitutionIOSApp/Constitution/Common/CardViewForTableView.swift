//
//  CardViewForTableView.swift
//  Constitution
//
//  Created by macmini on 17/05/21.
//

import UIKit


@IBDesignable class CardViewForTableView: UIView {
    
//    @IBInspectable var shadowWidth: Int = 0
//    @IBInspectable var shadowHeight: Int = 0
//    @IBInspectable var shadowOpacity: Float = 0.2
//    @IBInspectable var cornerRadius: CGFloat = 10
//    @IBInspectable var shadowColor: UIColor = .black
//
//    override func layoutSubviews() {
//
//        layer.cornerRadius = cornerRadius
//        layer.shadowColor = shadowColor.cgColor
//        layer.shadowOpacity = shadowOpacity
//
//        let path = UIBezierPath(roundedRect: bounds,cornerRadius: cornerRadius)
//
//        layer.shadowPath = path.cgPath
//        layer.shadowOffset = CGSize(width: shadowWidth, height: shadowHeight)
//
//    }
    
    
    var setupShadowDone: Bool = false
        
        public func setupShadow() {
            if setupShadowDone { return }
            self.layer.cornerRadius = 10
            self.layer.shadowOffset = CGSize(width: 0, height: 3)
            self.layer.shadowRadius = 4
            self.layer.shadowOpacity = 0.5
            self.layer.shadowColor = UIColor.gray.cgColor
            self.layer.shadowPath = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: .allCorners, cornerRadii: CGSize(width: 8, height: 8)).cgPath
            self.layer.shouldRasterize = true
            self.layer.rasterizationScale = UIScreen.main.scale
        
            setupShadowDone = true
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            setupShadow()
        }

}

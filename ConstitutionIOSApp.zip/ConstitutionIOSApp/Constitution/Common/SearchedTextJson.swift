//
//  SearchedTextJson.swift
//  Constitution
//
//  Created by macmini on 13/08/21.
//

import Foundation


struct SearchedTextJson: Codable {
    

    var id: Int
    var savedValue: String
    var searchedText: String
    var isSelected : Int
    
    
    init(id: Int, savedValue: String, searchedText: String) {
        

        self.id = id
        self.savedValue = savedValue
        self.searchedText = searchedText
        self.isSelected = 0
        
    }
    
    
    
}


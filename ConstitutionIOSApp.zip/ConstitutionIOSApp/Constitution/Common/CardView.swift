//
//  CardView.swift
//  Constitution
//
//  Created by macmini on 14/05/21.
//

import UIKit

@IBDesignable class CardView: UIView {
    
    @IBInspectable var shadowWidth: Int = 0
    @IBInspectable var shadowHeight: Int = 0
    @IBInspectable var shadowOpacity: Float = 0.2
    @IBInspectable var cornerRadius: CGFloat = 10
    @IBInspectable var shadowColor: UIColor = .black
        
    override func layoutSubviews() {
    
        layer.cornerRadius = cornerRadius
        layer.shadowColor = shadowColor.cgColor
        layer.shadowOpacity = shadowOpacity

        let path = UIBezierPath(roundedRect: bounds,cornerRadius: cornerRadius)

        layer.shadowPath = path.cgPath
        layer.shadowOffset = CGSize(width: shadowWidth, height: shadowHeight)


    
    }

}




//
//  DocumentView.swift
//  Constitution
//
//  Created by macmini on 11/08/21.
//


import UIKit

@IBDesignable class DocumentView: UIView {
    
    @IBInspectable var shadowWidth: Int = 0
    @IBInspectable var shadowHeight: Int = 0
    @IBInspectable var shadowOpacity: Float = 0.0
    @IBInspectable var cornerRadius: CGFloat = 0
    @IBInspectable var borderColor: UIColor = UIColor.init(red: 219.0/255.0, green: 157.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        
    override func layoutSubviews() {
    
        layer.cornerRadius = cornerRadius
        layer.shadowOpacity = shadowOpacity
        layer.borderWidth = 16
        layer.borderColor = borderColor.cgColor
        

        let path = UIBezierPath(roundedRect: bounds,cornerRadius: cornerRadius)

        layer.shadowPath = path.cgPath
        layer.shadowOffset = CGSize(width: shadowWidth, height: shadowHeight)


    
    }

}



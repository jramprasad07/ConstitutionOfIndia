//
//  HomePageViewController.swift
//  Constitution
//
//  Created by macmini on 15/05/21.
//

import UIKit
import SwiftyXMLParser

class HomePageViewController: UIViewController {
    
    
    @IBOutlet weak var homePageBackBtn: UIButton!
    @IBOutlet weak var headingLbl: UILabel!
    @IBOutlet weak var homeBtn: UIButton!
    @IBOutlet weak var homePageTableView: UITableView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var topViewHeight: NSLayoutConstraint!
    @IBOutlet weak var languageView: UIView!
    @IBOutlet weak var languageViewHeight: NSLayoutConstraint!
    
    
    // PART5 not displaying Adyayam1
    
    var selectedLanguage = String()
    
    var  currselnode:XMLElement = XMLElement(id: "",title: "", parttitle: "", subtitle: "", labeltitle: "",nodetype:0)
    var filePath = String()
    var articleTitle = String()
    
    var patharray : [XMLSubscriptType] = ["Constitution","section"];
    var xmlelements : [XMLElement] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        ViewInitialisation()
        
        
    }
    
    func ViewInitialisation() {
        
        self.homePageTableView.delegate = self
        self.homePageTableView.dataSource = self
        
        self.topView.isHidden = true
        self.topViewHeight.constant = 0.0
        self.languageView.isHidden = true
        self.languageViewHeight.constant = 0.0
        
        self.homePageBackBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        self.homeBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        if (self.selectedLanguage == "0") {
            self.headingLbl.text = "Constitution of India"
            self.filePath = Bundle.main.path(forResource: "EnglishFinalVersion", ofType: "xml") ?? ""
        } else if(self.selectedLanguage == "1") {
            self.headingLbl.text = "భారత సంవిధానము"
            self.filePath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") ?? ""
        }
        //        else if(self.selectedLanguage == "2") {
        
        //        } else if(self.selectedLanguage == "3") {
        
        //        } else if(self.selectedLanguage == "4") {
        
        //        } else if(self.selectedLanguage == "5") {
        
        //        }
        else {
            
        }
        
        
        //      if let filepath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") {
        do {
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            
            let xmlData = try! XML.parse(contents)
            xmlelements.removeAll()
            
            //var sections = xmlData[patharray];
            
            var i = 0
            for section in xmlData[patharray].all ?? [] {
                
                var sec  = XMLElement(id: String(i),title: "", parttitle: "", subtitle: "", labeltitle: "",nodetype:0)
                
                for secchilds in section.childElements {
                    if secchilds.name == "title" {
                        sec.title = secchilds.text ?? ""
                    }
                    if secchilds.name == "parttitle" {
                        sec.parttitle = secchilds.text ?? ""
                    }
                    if secchilds.name == "labeltitle" {
                        sec.labeltitle = secchilds.text ?? ""
                    }
                    if secchilds.name == "subtitle" {
                        sec.subtitle = secchilds.text ?? ""
                    }
                    
                }
                sec.patharray.append(i)
                xmlelements.append(sec)
                i += 1
                
            }
            
            self.homePageTableView.reloadData()
            
        } catch {
            // contents could not be loaded
            print(error)
        }
        //      } else {
        // example.txt not found!
        //        }
        
    }
    
    func getChilds(sec1 : Int) {
        
        //      if let filepath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") {
        do {
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            
            let xmlData = try! XML.parse(contents)
            
            //now check the childs of the clicked element
            //  patharray.append(sec1)
            
            // let testchilds : [XML.Element] = []
            let currnode = xmlelements[sec1].patharray
            
            for childs in xmlData[currnode].all ?? [] {
                
                if childs.childElements.count == 1 && (childs.name == "article" || childs.name == "section") {
                    
                    let preambleVC = storyboard?.instantiateViewController(withIdentifier: "PreambleViewController") as! PreambleViewController
                    preambleVC.articleTitle = self.articleTitle
                    preambleVC.articleDesc = childs.text ?? ""
                    self.navigationController?.pushViewController(preambleVC, animated: true)
                    
                } else {
                    
                    for child in childs.childElements {
                        
                        //print("child is \(child.name)")
                        //if there are no child then display the content
                        //if there is a child then check the child name and add the same to path
                        //if it is parts then again get childs (parts or chapters or articles) and populate the array and path
                        //if it is chapters then get childs subsection or articles and populate the array an path
                        //if it is subsections then get articles and populate the array and path
                        //if it is articles then get article and populate the array and path
                        //if it is article then no childs and show the content
                        
                        switch child.name {
                        case "parts":
                            PopulateParts(currnode:currnode, nodetype:1)
                            break;
                        case "chapter":
                            PopulateParts(currnode:currnode, nodetype:2)
                            //PopulateChapters(currnode:currnode)
                            break;
                        case "subsection":
                            PopulateParts(currnode:currnode, nodetype:3)
                            //PopulateSubsections(currnode:currnode)
                            break;
                        case "articles":
                            PopulateParts(currnode:currnode, nodetype:4)
                            //PopulateArticles(currnode:currnode)
                            break;
                        case "article":
                            PopulateParts(currnode:currnode, nodetype:5)
                            //PopulateArticle(currnode:currnode)
                            break;
                        default:
                            print("default")
                            break;
                        }
                    }
                    
                }
            }
        }
        catch {
            // contents could not be loaded
            print(error)
        }
        
    }
    
    
    func PopulateParts(currnode:[XMLSubscriptType], nodetype : Int) {
        
        do{
            //as this is part, populate parts and part to the xmlsubscripttype
            var temp = currnode
            currselnode.patharray = currnode
            currselnode.nodetype = nodetype
            
            switch nodetype {
            //parts
            case 1:
                temp.append("parts")
                temp.append("part")
                break;
            //chapters
            case 2:
                temp.append("chapter")
                
            //section
            case 3:
                temp.append("subsection")
            //articles
            case 4:
                temp.append("articles")
                temp.append("article")
            //article
            case 5:
                temp.append("article")
            default:
                print("the node type sent is \(nodetype)")
            }
            
            getnodes(temp:temp, nodetype:nodetype)
        } catch {
            // contents could not be loaded
            print(error)
        }
        
        
    }
    
    func getnodes(temp:[XMLSubscriptType], nodetype : Int){
        //var xmlelements : [XMLElement] = []
        
        //    if let filepath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") {
        do {
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            
            let xmlData = try! XML.parse(contents)
            
            xmlelements.removeAll()
            var i = 0
            
            for childs in xmlData[temp].all ?? [] {
                
                var sec  = XMLElement(id: "",title: "", parttitle: "", subtitle: "", labeltitle: "", nodetype: nodetype)
                sec.patharray = temp
                sec.patharray.append(i)
                
                i += 1
                for child in childs.childElements {
                    //print(child.name)
                    
                    switch child.name {
                    case "title":
                        sec.title = child.text ?? ""
                        break;
                    case "parttitle":
                        sec.parttitle = child.text ?? ""
                        sec.title = child.text ?? ""
                        
                        break;
                    case "labeltitle":
                        sec.labeltitle = child.text ?? ""
                        break;
                    case "subtitle":
                        sec.subtitle = child.text ?? ""
                        break;
                    default:
                        print(child.name)
                    }
                    
                }
                xmlelements.append(sec)
            }
            
        } catch {
            // contents could not be loaded
            print(error)
        }
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: animated)
        
        //        ViewInitialisation()
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: animated)
        
    }
    
    @IBAction func HomePageBackBtnAction(_ sender: Any) {
        
        if (currselnode.nodetype == 0){
            navigationController?.popViewController(animated: true)
        } else {
            //  print("arr is \(currselnode.patharray)")
            //PopulateParts(currnode:currselnode.patharray, nodetype:currselnode.nodetype)
            if (currselnode.patharray.count > 2 ) {//stop at sections level
                //   print("last \(currselnode.patharray.last)")
                currselnode.patharray.removeLast(1)
                
                if(currselnode.patharray.last is Int){
                    // print("last \(currselnode.patharray.last)")
                    currselnode.patharray.removeLast(1)
                    
                }
                if(currselnode.patharray.last is String){
                    // print("last \(currselnode.patharray.last)")
                    
                    if(currselnode.patharray.last as! String == "parts" || currselnode.patharray.last as! String == "articles"){
                        currselnode.patharray.removeLast(1)
                        if(currselnode.patharray.last is Int){
                            //  print("last \(String(describing: currselnode.patharray.last))")
                            currselnode.patharray.removeLast(1)
                        }
                    }
                }
                getnodes(temp:currselnode.patharray, nodetype:currselnode.nodetype)
                //print("arr1 is \(currselnode.patharray)")
                homePageTableView.reloadData()
            } else {
                navigationController?.popViewController(animated: true)
            }
            
        }
    }
    
    
    @IBAction func HomeBtnAction(_ sender: Any) {
        
        navigationController?.popToRootViewController(animated: true)
        
    }
    
    
}

extension HomePageViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return xmlelements.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (tableView == homePageTableView) {
            
            let homeCell = tableView.dequeueReusableCell(withIdentifier: "HomePageTableViewCell", for: indexPath) as? HomePageTableViewCell
            
            homeCell?.homePageItemNameLbl.text = self.xmlelements[indexPath.row].title
            homeCell?.descLbl.text = self.xmlelements[indexPath.row].subtitle
            homeCell?.indexLbl.text = self.xmlelements[indexPath.row].labeltitle
            
            homeCell?.currId = self.xmlelements[indexPath.row].id
            
            homeCell?.tag = indexPath.row
            homeCell?.patharray = self.xmlelements[indexPath.row].patharray
            
            return homeCell!
            
            
        }
        
        return UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if (tableView == homePageTableView) {
            
            self.articleTitle = self.xmlelements[indexPath.row].title
            //currselnode = xmlelements[indexPath.row]
            getChilds(sec1:indexPath.row)
            
            homePageTableView.reloadData()
            
            
        }
        
    }
    
    
    
}



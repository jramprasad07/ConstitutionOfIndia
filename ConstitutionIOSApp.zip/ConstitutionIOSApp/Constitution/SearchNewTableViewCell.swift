//
//  SearchNewTableViewCell.swift
//  Constitution
//
//  Created by macmini on 13/08/21.
//

import UIKit
import SwiftyXMLParser

class SearchNewTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var headingLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var searchIndexLbl: UILabel!
    
    var currId = "0"
    var patharray: [XMLSubscriptType] = []

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

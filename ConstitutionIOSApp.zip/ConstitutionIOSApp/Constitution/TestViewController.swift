//
//  TestViewController.swift
//  Constitution
//
//  Created by macmini on 03/06/21.
//

import UIKit

class TestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //  Latest updated on 158221
        
        //Latest version 1.0.7 **** 15822 ****
        
        
        
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare (for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
     
     //     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
     
    */

}


//https://github.com/chenyunguiMilook/SwiftyXML
//https://github.com/yahoojapan/swSwiftyXMLParser


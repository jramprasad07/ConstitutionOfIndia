//
//  PreambleViewController.swift
//  Constitution
//
//  Created by macmini on 17/05/21.
//

import UIKit


class PreambleViewController: UIViewController {
    
 
    @IBOutlet weak var preambleBackBtn: UIButton!
    @IBOutlet weak var preambleHomeBtn: UIButton!
    @IBOutlet weak var headingLbl: UILabel!
    @IBOutlet weak var preambleTitleLbl: UILabel!
    @IBOutlet weak var preambleTextLbl: UILabel!
    @IBOutlet weak var shareBtn: UIButton!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var bottomViewHeight: NSLayoutConstraint!
    
    
    var selectedLanguage = String()
    var articleTitle = String()
    var articleDesc = String()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    
        ViewInitialisation()
        

    }
    
    func ViewInitialisation() {
        
        
        shareBtn.layer.cornerRadius = shareBtn.frame.height * 0.50
        
        self.bottomView.isHidden = true
        self.bottomViewHeight.constant = 20.0
        
        self.preambleBackBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        self.preambleHomeBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        
        if (self.selectedLanguage == "0") {
            self.headingLbl.text = "Constitution of India"
        } else if(self.selectedLanguage == "1") {
            self.headingLbl.text = "భారత సంవిధానము"
        }
        
        
        self.preambleTitleLbl.text = articleTitle
        self.preambleTextLbl.text = articleDesc
        
        
 //       self.preambleTextLbl.backgroundColor = UIColor(patternImage: UIImage(named: "national_emblem_bw_trns")!)
        
        
        
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            
        navigationController?.setNavigationBarHidden(true, animated: animated)
        self.tabBarController?.tabBar.isHidden = false
            
        ViewInitialisation()
            
            
    }
        
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
            
        navigationController?.setNavigationBarHidden(false, animated: animated)
    
    }
    
    @IBAction func PreambleBackBtnAction(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
//        navigationController?.popToRootViewController(animated: true)
        
    }
    

    @IBAction func PreambleHomeBtnAction(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    
    
    @IBAction func PreambleShareBtnAction(_ sender: Any) {
        
        
        // text to share
        let text = "\(self.preambleTitleLbl.text ?? "") \n\n\(self.preambleTextLbl.text ?? "")"
                
        // set up activity view controller
        let textToShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
                
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
                
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
        
        
    }
    
    
    

}

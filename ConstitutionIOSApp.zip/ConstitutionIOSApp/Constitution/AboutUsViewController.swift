//
//  AboutUsViewController.swift
//  Constitution
//
//  Created by macmini on 11/08/21.
//

import UIKit

class AboutUsViewController: UIViewController {
    
    
    @IBOutlet weak var topHeadingLbl: UILabel!
    @IBOutlet weak var aboutUsBackBtn: UIButton!
    @IBOutlet weak var firstParagraphLbl: UILabel!
    @IBOutlet weak var secondParagraphLbl: UILabel!
    @IBOutlet weak var thirdParagraphLbl: UILabel!
    @IBOutlet weak var fourthParagraphLbl: UILabel!
    @IBOutlet weak var fifthParagraphLbl: UILabel!
    @IBOutlet weak var sixthHeadingLbl: UILabel!
    @IBOutlet weak var commiteeMembersLbl: UILabel!
    @IBOutlet weak var advisorLbl: UILabel!
    @IBOutlet weak var chairmanLbl: UILabel!
    @IBOutlet weak var bottomViewHeight: NSLayoutConstraint!
    
    
    var selectedLanguage = String()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ViewInitialisation()
        
        
        
    }
    
    func ViewInitialisation() {
        
        self.aboutUsBackBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.topHeadingLbl.isHidden = false
        self.bottomViewHeight.constant = 90.0
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        if (self.selectedLanguage == "0") {
            self.topHeadingLbl.text = "Constitution of India"
        } else if(self.selectedLanguage == "1") {
            self.topHeadingLbl.text = "భారత సంవిధానము"
        }
        
        
        self.firstParagraphLbl.text = "FOLLOWING THE RISE AND FALL OF MOURYA AND GUPTA DYNASTIES, INDIAN SUBCONTINENT WAS RULED BY MANY PRINCELY STATES AND KINGDOMS INDIA TOOK THE CURRENT GEOGRAPHIC SHAPE PARTIALLY DURING THE BRITISH RULE AND FULLY AFTER ITS INDEPENDENCE IN 1947."
        
        self.secondParagraphLbl.text = "INDIA IS A DIVERSE COUNTRY WITH DIFFERENT LANGUAGES, CULTURES OF DIFFERENT RELIGIONS AND REGIONS. PRIOR TO THE PRESENT-DAY CONSTITUTION THAT CAME INTO EXISTNCE AND ADOPTED IN 01/26/1950, INDIAN SUBCONTINENT HAD TWO IMPORTANT ACTS THAT HAD PRESENTED THE FUNDAMENTAL RIGHTS TO INDIAN PUBLIC,"
        
        self.thirdParagraphLbl.text = "1. THE GOVERNMENT OF INDIA ACT OF 1919 &\n2. THE GOVERNMENT OF INDIA ACT 1935."
        
        self.fourthParagraphLbl.text = "IN 1946, BRITISH DECIDED TO GRANT INDEPENDENCE TO INDIA. AS A RESULT OF THAT DECISION, CONSTITUENT ASSEMBLY (CA) WAS ELECTED WITH 278 REPRESENTATTIVES. THE CA MET FOR THE FIRST TIME IN DECEMBER’1946 TO DISCUSS ABOUT SHAPE AND SPIRIT OF CONSTITUTION. ON AUGUST’29,1947, THE CA APPOINTED DRAFTING COMMITTEE MEMBERS AND DR.BR.AMBEDKAR AS THE CHAIRMAN TO THE CONSTITUTION DRAFTING COMITEE."
        
        self.fifthParagraphLbl.text = "AFTER EXTENSIVE DELIBARATIONS OF THE CONSTITUENT ASSEMBLY, THE CA ADOPTS FINAL DRAFT MAKING IT OFFICIAL ON NOVEMBER1949 AND CAME INTO FORCE ON 26 JANUARY 1950. INDIA CELEBRATES INDIAN REPUBLIC DAY ON THIS VERY HISTORICAL DAY, MARKED VERY IMPORTANT DAY IN THE INDIAN MODERN HISTORY."
        
        self.sixthHeadingLbl.text = "INDIAN CONSTITUTION DRAFTING COMMITTEE MEMBERS:"
        
        self.commiteeMembersLbl.text = "1) ALLADI KRISHNA SWAMI AYYAR \n\n2) N. GOPALASWAMI \n\n3) K.M. MUNSHI \n\n4) MOHAMMAD SAADULLA \n\n5) B.L. MITTER \n\n6) D.P. KHAITAN"
        
        self.advisorLbl.text = "B.N RAU"
        
        self.chairmanLbl.text = "BHIMRAO RAMJI AMBEDKAR"
        
        
        
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            
        navigationController?.setNavigationBarHidden(true, animated: animated)
            
        ViewInitialisation()
            
            
    }
        
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
            
        navigationController?.setNavigationBarHidden(false, animated: animated)
    
    }
    

    @IBAction func AboutUsBackBtnAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}

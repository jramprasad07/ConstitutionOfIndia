//
//  SearchNewViewController.swift
//  Constitution
//
//  Created by macmini on 13/08/21.
//

import UIKit
import SwiftyXMLParser

class SearchNewViewController: UIViewController, UISearchBarDelegate {
    
    
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var headingLbl: UILabel!
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var searchNewTableView: UITableView!
    @IBOutlet weak var searchBtn: UIButton!
    @IBOutlet weak var serTextField: UITextField!
    @IBOutlet weak var searchBView: UIView!
    
    var searchArticleNames = ["Article 001", "Article 002", "Article 002a", "Article 003", "Article 004"]
    
    // var searchedDesc = [String]()
    
    //    var searchedDesc = [XMLElement]()
    var searchedDesc : [XMLElement] = []
    
    var searchedTextArray: [SearchedTextJson] = []
    var name = String()
    
    var articleTitle = String()
    var articleText = String()
    var  currselnode : XMLElement = XMLElement(id: "", title: "", parttitle: "", subtitle: "", labeltitle: "", nodetype:0)
    
    var selectedLanguage = String()
    
    var patharray : [XMLSubscriptType] = ["Constitution","section"]
    var xmlelements : [XMLElement] = []
    var filePath = String()
    var serText = String()
    
    var xmlData : Any = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        ViewInitialisation()
        
        
    }
    
    func ViewInitialisation() {
        
        self.hideKeyboardWhenTappedAround()
        
        self.backBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        if (self.selectedLanguage == "0") {
            self.headingLbl.text = "Constitution of India"
            self.filePath = Bundle.main.path(forResource: "EnglishFinalVersion", ofType: "xml") ?? ""
        } else if(self.selectedLanguage == "1") {
            self.headingLbl.text = "భారత సంవిధానము"
            self.filePath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") ?? ""
        }
        
        self.serTextField.text = UserDefaults.standard.value(forKey: "searchTextFromHistory") as? String ?? ""
        
        self.searchNewTableView.delegate = self
        self.searchNewTableView.dataSource = self
        
        self.saveBtn.isHidden = true
        
        self.searchBView.layer.cornerRadius = 20
        self.searchBView.layer.borderWidth = 1
        self.searchBView.layer.borderColor = CGColor.init(red: 56.0/255.0, green: 118.0/255.0, blue: 242.0/255.0, alpha: 1.0)
        
        
        // Read/Get Data
        if let data = UserDefaults.standard.data(forKey: "savedSearch") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()
                // Decode Note
                searchedTextArray = try decoder.decode([SearchedTextJson].self, from: data)
               // print("--51-----**----Already saved seach--**--:: \(searchedTextArray)")
                
                for items in 0..<searchedTextArray.count {
                    self.name = self.searchedTextArray[items].searchedText
                 //   print("--56--already searched text--- \(self.name)")
                    
                }
                
            } catch {
                print("Unable to Decode Note (\(error))")
            }
        } else {
            
            
        }
        
        self.searchNewTableView.estimatedRowHeight = 110.0
        self.searchNewTableView.rowHeight = UITableView.automaticDimension
        
        self.searchNewTableView.tableFooterView = UIView()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: animated)
        //       ViewInitialisation()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: animated)
        
    }
    
    @IBAction func BackBtnAction(_ sender: Any) {
        //     navigationController?.popViewController(animated: true)
        
        if (currselnode.nodetype == 0){
            navigationController?.popViewController(animated: true)
        } else {
            //  print("arr is \(currselnode.patharray)")
            //PopulateParts(currnode:currselnode.patharray, nodetype:currselnode.nodetype)
            if (currselnode.patharray.count > 2 ) {//stop at sections level
                //   print("last \(currselnode.patharray.last)")
                currselnode.patharray.removeLast(1)
                
                if(currselnode.patharray.last is Int){
                    // print("last \(currselnode.patharray.last)")
                    currselnode.patharray.removeLast(1)
                    
                }
                if(currselnode.patharray.last is String){
                    // print("last \(currselnode.patharray.last)")
                    
                    if(currselnode.patharray.last as! String == "parts" || currselnode.patharray.last as! String == "articles"){
                        currselnode.patharray.removeLast(1)
                        if(currselnode.patharray.last is Int){
                            //  print("last \(String(describing: currselnode.patharray.last))")
                            currselnode.patharray.removeLast(1)
                        }
                    }
                }
                getnodes(temp:currselnode.patharray, nodetype:currselnode.nodetype)
                //print("arr1 is \(currselnode.patharray)")
                searchNewTableView.reloadData()
            } else {
                navigationController?.popViewController(animated: true)
            }
            
        }
        
    }
    
    @IBAction func SearchBtnAction(_ sender: Any) {
        
        searchedDesc = []
        
        serText = serTextField.text!
        if(serText.count <= 2) {
            self.saveBtn.isHidden = true
            self.toastMessage("Please enter atleast 3 letters to search")
        } else {
            print("--serText.lowercased()---\(serText.lowercased())")
            var patharray : [XMLSubscriptType] = ["Constitution","section"];
            
            FillSearchResults(patharray: patharray)
            
            self.saveBtn.isHidden = false
        }
        
        self.hideKeyboardWhenTappedAround()
        
        self.searchNewTableView.reloadData()
        
    }
    
    @IBAction func SaveBtnAction(_ sender: UIButton) {
        
        
        //1. Create the alert controller.
        let alert = UIAlertController(title: "Save search results", message: "Please enter value to save search results", preferredStyle: .alert)
        
        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.placeholder = "Enter value..."
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { [weak alert] (_) in
            
            self.view.endEditing(true)
            
        }))
        
        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { [weak alert] (_) in
            
            let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
            
            if(textField!.text!.isEmpty){
                
                self.view.endEditing(true)
                self.toastMessage("Please enter valid text")
            } else {
                print("Text field: \(textField!.text!)")
                
                var saveSearch = SearchedTextJson(id: 0, savedValue: "", searchedText: "")
                
                saveSearch.id = sender.tag
                saveSearch.savedValue = textField!.text!
                saveSearch.searchedText = self.serTextField.text!
                
                self.searchedTextArray.append(saveSearch)
                
                do {
                    // Create JSON Encoder
                    let encoder = JSONEncoder()
                    // Encode Note
                    let data = try encoder.encode(self.searchedTextArray)
                    // Write/Set Data
                    UserDefaults.standard.set(data, forKey: "savedSearch")
                } catch {
                    print("Unable to Encode Note (\(error))")
                }
                self.view.endEditing(true)
                self.toastMessage("Search saved successfully")
                
            }
            
        }))
        
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func FillSearchResults( patharray : [XMLSubscriptType]) {
        
        do {
            
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            
            let xmlData = try! XML.parse(contents)
            var searchText =  serTextField.text!
            var searchText1 = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            
            searchedDesc.removeAll()
            
            //search at sections level
            var patharray1 : [XMLSubscriptType] = patharray;
            
            let temp = xmlData[patharray1].all ?? []
            
            var sectioncount = 0
            for child in temp {
                
                var temp = FillTitles(node: child, searchText: searchText1,patharray: patharray1)
                
                if(temp != nil) {
                   
                    temp?.patharray = patharray1
                    temp?.patharray.append(sectioncount)
                    searchedDesc.append(temp!)
                }
                
                if(child.name == "title" || child.name == "parttitle" || child.name=="labeltitle" || child.name == "subtitle"){
                    
                } else {
                    patharray1 = ["Constitution","section"];
                    patharray1.append(sectioncount)
                    //print("the section list\(patharray)")
                    sectioncount = sectioncount + 1
                    
                    FillParts(patharray: patharray1,xml: xmlData, searchText : searchText1)
                    
                }
                
            }
            
            //print("the filtered list\(searchedDesc)")
        } catch {
            // contents could not be loaded
            print(error)
        }
        
    }
    
    func FillParts(patharray: [XMLSubscriptType],xml : XML.Accessor, searchText : String){
        
        // var patharray : [XMLSubscriptType] = ["Constitution","section"];
        var partspath : [XMLSubscriptType] = ["Constitution","section"];
        
        var partcount = 0
        //find in parts
        partspath = patharray
        partspath.append("parts")
        partspath.append("part")
        
        for parts in xml[partspath].all ?? []{
            
            var temp = FillTitles(node: parts, searchText: searchText,patharray: partspath)
            
            if(temp != nil) {
                partspath.append(partcount)
                temp?.patharray = partspath
                searchedDesc.append(temp!)
            }
            
            if(parts.name == "title" || parts.name == "parttitle" || parts.name=="labeltitle" || parts.name == "subtitle"){
                
            } else {
                partspath = patharray
                partspath.append("parts")
                partspath.append("part")
                partspath.append(partcount)
                // print("the part list\(partspath)")
                partcount = partcount + 1
                
                //loop for chapter
                FillChapters(patharray: partspath,xml : xml, searchText: searchText)
                //loop for subsection
                //there can be subsection under part
                FillSubsections(patharray: partspath,xml : xml, searchText: searchText)
                //loop for articles
                FillArticles(patharray : partspath , xml : xml, searchText: searchText)
                
                
            }
            
        }
    }
    
    func FillChapters(patharray: [XMLSubscriptType],xml : XML.Accessor, searchText : String){
        
        var chapterpath : [XMLSubscriptType] = ["Constitution","section"];
        var chaptercount = 0
        chapterpath = patharray
        chapterpath.append("chapter")
        
        for chapter in xml[chapterpath].all ?? []{
            
            var temp = FillTitles(node: chapter, searchText: searchText,patharray: chapterpath)
            
            if(temp != nil) {
                chapterpath.append(chaptercount)
                temp?.patharray = chapterpath
                searchedDesc.append(temp!)
            }
            
            if(chapter.name == "title" || chapter.name == "parttitle" || chapter.name=="labeltitle" || chapter.name == "subtitle"){
                
                                
            } else {
                chapterpath = patharray
                chapterpath.append("chapter")
                chapterpath.append(chaptercount)
                // print("the part list\(chapterpath)")
                chaptercount = chaptercount + 1
                
                //there can be subsection under chapter
                FillSubsections(patharray: chapterpath,xml : xml, searchText: searchText)
                //there can be articles under chapter
                FillArticles(patharray : chapterpath,xml : xml, searchText: searchText)
                
            }
            
        } //end of chapter -
    }
    
    func FillSubsections(patharray: [XMLSubscriptType],xml : XML.Accessor, searchText: String){
        
        var subsectionpath : [XMLSubscriptType] = ["Constitution","section"]
        var subsectioncount = 0
        subsectionpath = patharray
        subsectionpath.append("subsection")
        
        for subsection in xml[subsectionpath].all ?? []{
            
            var temp = FillTitles(node: subsection, searchText: searchText,patharray: subsectionpath)
            
            if(temp != nil) {
                subsectionpath.append(subsectioncount)
                temp?.patharray = subsectionpath
                searchedDesc.append(temp!)
            }
            
            if(subsection.name == "title" || subsection.name == "parttitle" || subsection.name=="labeltitle" || subsection.name == "subtitle"){
                
            } else {
                
                //there can be subsection under chapter
                
                subsectionpath = patharray
                subsectionpath.append("subsection")
                subsectionpath.append(subsectioncount)
                //print("the part list\(subsectionpath)")
                subsectioncount = subsectioncount + 1
                
                //there can be articles under chapter
                FillArticles(patharray : subsectionpath, xml : xml, searchText: searchText)
                
            }
        } //end of chapter -> subsection
    }

    func FillArticles(patharray: [XMLSubscriptType],xml : XML.Accessor, searchText : String){
        
        var articlespath : [XMLSubscriptType] = ["Constitution","section"];
        var articlescount = 0
        articlespath = patharray
        articlespath.append("articles")
        articlespath.append("article")
        
        for article in xml[articlespath].all ?? []{
            
            var temp = FillTitles(node: article, searchText: searchText,patharray: articlespath)
            
            if(temp != nil) {
                articlespath = patharray
                articlespath.append("articles")
                articlespath.append("article")
                articlespath.append(articlescount)
                temp?.patharray = articlespath
                searchedDesc.append(temp!)
            }
            
            if(article.name == "title" || article.name == "parttitle" || article.name=="labeltitle" || article.name == "subtitle"){
                
            } else {
                
                //there can be articles under chapter
                
                articlespath = patharray
                articlespath.append("articles")
                articlespath.append("article")
                articlespath.append(articlescount)
                //print("the part list\(articlespath)")
                articlescount = articlescount + 1
                
            }
        }
    }
    
    func  FillTitles(node: XML.Element, searchText : String,patharray: [XMLSubscriptType]) -> XMLElement? {
        
        var temp : XMLElement = XMLElement(id: "",title: "", parttitle: "", subtitle: "", labeltitle: "",nodetype:0)
        
        temp.patharray = patharray
        var found = false
        
        if node.text?.lowercased().contains(searchText) == true{
            
            found = true
            
            for secchilds in node.childElements {
                
                if secchilds.name == "title" {
                    temp.title = (temp.title == "") ? (secchilds.text ?? "") : temp.title
                }
                if secchilds.name == "parttitle" {
                    temp.parttitle = (temp.parttitle == "") ? (secchilds.text ?? "") : temp.parttitle
                }
                if secchilds.name == "labeltitle" {
                    temp.labeltitle = (temp.labeltitle == "") ? (secchilds.text ?? "") : temp.labeltitle
                }
                if secchilds.name == "subtitle" {
                    temp.subtitle = temp.subtitle == "" ? (secchilds.text ?? "") : temp.subtitle
                }
            }
        }
        
        for secchild in node.childElements {
            
            if secchild.text?.lowercased().contains(searchText.lowercased()) == true{
                
                found = true
                
                var secp = secchild.parentElement
                for secchilds in secp!.childElements {
                    if secchilds.name == "title" {
                        temp.title = (temp.title == "") ? (secchilds.text ?? "") : temp.title
                    }
                    if secchilds.name == "parttitle" {
                        temp.parttitle = (temp.parttitle == "") ? (secchilds.text ?? "") : temp.parttitle
                    }
                    if secchilds.name == "labeltitle" {
                        temp.labeltitle = (temp.labeltitle == "") ? (secchilds.text ?? "") : temp.labeltitle
                    }
                    if secchilds.name == "subtitle" {
                        temp.subtitle = temp.subtitle == "" ? (secchilds.text ?? "") : temp.subtitle
                    }
                }
            }
        }

        return (found) ? temp : nil
    }
    
    //On click tableview Item papulate childs
    
    func getChilds(sec1 : Int) {
        
        //      if let filepath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") {
        do {
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            
            let xmlData = try! XML.parse(contents)
            
            //now check the childs of the clicked element
            //  patharray.append(sec1)
            
            // let testchilds : [XML.Element] = []
            let currnode = searchedDesc[sec1].patharray
            //            let currnode = patharray
            
            for childs in xmlData[currnode].all ?? [] {
                
                if childs.childElements.count == 1 && (childs.name == "article" || childs.name == "section") {
                    
                    let preambleVC = storyboard?.instantiateViewController(withIdentifier: "PreambleViewController") as! PreambleViewController
                    preambleVC.articleTitle = self.articleTitle
                    preambleVC.articleDesc = childs.text ?? ""
                    self.navigationController?.pushViewController(preambleVC, animated: true)
                    break
                    
                } else {
                    
                    for child in childs.childElements {
                        
                        //print("child is \(child.name)")
                        //if there are no child then display the content
                        //if there is a child then check the child name and add the same to path
                        //if it is parts then again get childs (parts or chapters or articles) and populate the array and path
                        //if it is chapters then get childs subsection or articles and populate the array an path
                        //if it is subsections then get articles and populate the array and path
                        //if it is articles then get article and populate the array and path
                        //if it is article then no childs and show the content
                        
                        switch child.name {
                        case "parts":
                            PopulateParts(currnode:currnode, nodetype:1)
                            break;
                        case "chapter":
                            PopulateParts(currnode:currnode, nodetype:2)
                            //PopulateChapters(currnode:currnode)
                            break;
                        case "subsection":
                            PopulateParts(currnode:currnode, nodetype:3)
                            //PopulateSubsections(currnode:currnode)
                            break;
                        case "articles":
                            PopulateParts(currnode:currnode, nodetype:4)
                            //PopulateArticles(currnode:currnode)
                            break;
                        case "article":
                            PopulateParts(currnode:currnode, nodetype:5)
                            //PopulateArticle(currnode:currnode)
                            break;
                        default:
                            print("default")
                            break;
                        }
                    }
                    
                }
            }
        }
        catch {
            // contents could not be loaded
            print(error)
        }
        
        // }
        
    }
    
    func PopulateParts(currnode:[XMLSubscriptType], nodetype : Int) {
        
        do{
            //as this is part, populate parts and part to the xmlsubscripttype
            var temp = currnode
            currselnode.patharray = currnode
            currselnode.nodetype = nodetype
            
            switch nodetype {
            //parts
            case 1:
                temp.append("parts")
                temp.append("part")
                break;
            //chapters
            case 2:
                temp.append("chapter")
                
            //section
            case 3:
                temp.append("subsection")
            //articles
            case 4:
                temp.append("articles")
                temp.append("article")
            //article
            case 5:
                temp.append("article")
            default:
                print("the node type sent is \(nodetype)")
            }
            
            getnodes(temp:temp, nodetype:nodetype)
        } catch {
            // contents could not be loaded
            print(error)
        }
        
    }
    
    func getnodes(temp:[XMLSubscriptType], nodetype : Int){
        //FillSearchResults(patharray: temp)
        //    if let filepath = Bundle.main.path(forResource: "TeluguFinalVersion", ofType: "xml") {
        do {
            let contents = try String(contentsOfFile: filePath)
            //print(contents)
            let xmlData = try! XML.parse(contents)

            searchedDesc.removeAll()
            var i = 0

            for childs in xmlData[temp].all ?? [] {

                var sec  = XMLElement(id: "",title: "", parttitle: "", subtitle: "", labeltitle: "", nodetype: nodetype)
                sec.patharray = temp
                sec.patharray.append(i)

                i += 1
                for child in childs.childElements {
                    //print(child.name)

                    switch child.name {
                    case "title":
                        sec.title = child.text ?? ""
                        break;
                    case "parttitle":
                        sec.parttitle = child.text ?? ""
                        sec.title = child.text ?? ""

                        break;
                    case "labeltitle":
                        sec.labeltitle = child.text ?? ""
                        break;
                    case "subtitle":
                        sec.subtitle = child.text ?? ""
                        break;
                    default:
                        print(child.name)
                    }
                }
                searchedDesc.append(sec)
            }

        } catch {
            // contents could not be loaded
            print(error)
        }
//
    }
    
}


extension SearchNewViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchedDesc.count
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (tableView == searchNewTableView) {
            
            let searchCell = tableView.dequeueReusableCell(withIdentifier: "SearchNewTableViewCell", for: indexPath) as? SearchNewTableViewCell
            
//            print("*-**-*-**---861--*--title----\(searchedDesc[indexPath.row].title)")
//            print("*-**-*-**---862--*--content----\(searchedDesc[indexPath.row].content)")
//            print("*-**-*-**---863--*--parttitle----\(searchedDesc[indexPath.row].parttitle)")
//            print("*-**-*-**---864--*--labeltitle----\(searchedDesc[indexPath.row].labeltitle)")
//            print("*-**-*-**---865--*--subtitle----\(searchedDesc[indexPath.row].subtitle)")
//            print("*-**-*-**---865--*--title----\(searchedDesc[indexPath.row].title)")
//
            /*    if(searchedDesc[indexPath.row].title.isEmpty) {
             searchCell?.headingLbl.text = searchedDesc[indexPath.row].parttitle
             } else {
             searchCell?.headingLbl.text = searchedDesc[indexPath.row].title
             }*/
            
            if(searchedDesc[indexPath.row].title.isEmpty) {
                if(searchedDesc[indexPath.row].parttitle.isEmpty) {
                    if(searchedDesc[indexPath.row].subtitle.isEmpty) {
                        if(searchedDesc[indexPath.row].labeltitle.isEmpty) {
                            
                        } else {
                            searchCell?.headingLbl.text = searchedDesc[indexPath.row].labeltitle
                        }
                    } else {
                        searchCell?.headingLbl.text = searchedDesc[indexPath.row].subtitle
                    }
                } else {
                    searchCell?.headingLbl.text = searchedDesc[indexPath.row].parttitle
                }
            } else {
                searchCell?.headingLbl.text = searchedDesc[indexPath.row].title
            }
            
            /*searchCell?.headingLbl.text = searchedDesc[indexPath.row].title
            searchCell?.descLbl.text = searchedDesc[indexPath.row].content*/
            
            searchCell?.descLbl.text = searchedDesc[indexPath.row].subtitle
            searchCell?.descLbl.numberOfLines = 2
            
            if(searchedDesc[indexPath.row].labeltitle.isEmpty){
                searchCell?.searchIndexLbl.isHidden = true
            } else {
                searchCell?.searchIndexLbl.isHidden = false
                searchCell?.searchIndexLbl.text = searchedDesc[indexPath.row].labeltitle
            }
            
            
            
            
            searchCell?.currId = self.searchedDesc[indexPath.row].id
            searchCell?.tag = indexPath.row
            searchCell?.patharray = self.searchedDesc[indexPath.row].patharray
            
            
            return searchCell!
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if (tableView == searchNewTableView) {
            
            
            self.articleTitle = self.searchedDesc[indexPath.row].title
            getChilds(sec1:indexPath.row)
            
            searchNewTableView.reloadData()
            
            
        }
    }
}



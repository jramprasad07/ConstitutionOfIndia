//
//  ContactViewController.swift
//  Constitution
//
//  Created by macmini on 15/05/21.
//

import UIKit

class ContactViewController: UIViewController {

    @IBOutlet weak var contactPageBackBtn: UIButton!
    @IBOutlet weak var topHeadingLbl: UILabel!
    @IBOutlet weak var firstParagraphLbl: UILabel!
    @IBOutlet weak var secondParagraphLbl: UILabel!
    @IBOutlet weak var thirdParagraphLbl: UILabel!
    @IBOutlet weak var fourthParagraphLbl: UILabel!
    @IBOutlet weak var fifthParagraphLbl: UILabel!
    @IBOutlet weak var sixthParagraphLbl: UILabel!
    @IBOutlet weak var thankYouLbl: UILabel!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var bottomViewHeight: NSLayoutConstraint!
    

    var selectedLanguage = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ViewInitialisation()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            
        navigationController?.setNavigationBarHidden(true, animated: animated)
            
        ViewInitialisation()
            
            
    }
    
    
    func ViewInitialisation() {
        
        self.contactPageBackBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.topHeadingLbl.isHidden = false
        self.bottomViewHeight.constant = 40.0
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        if (self.selectedLanguage == "0") {
            self.topHeadingLbl.text = "Constitution of India"
        } else if(self.selectedLanguage == "1") {
            self.topHeadingLbl.text = "భారత సంవిధానము"
        }
        
        
       /* self.firstParagraphLbl.text = "THE MAIN GOAL OF THIS APP IS TO BRING CONSTITUTION AWARENESS IN THE INDIAN PUBLIC. BEING INTEACTING WITH PEOPLE FROM DIFFERENT PARTS OF THE WORLD, I UNDERSTAND THAT PUBLIC FROM MANY DEVELOPING NATIONS HAS BETTER UNDERSTANDING OF THEIR CONSTITUTION COMPARED ANY INDIAN WE KNOW."
        
        self.secondParagraphLbl.text = "WHEN WE (MY WIFE AND MYSELF) FURTHER INTRIGUED INTO THE REASONS FOR UNDERSTANDING IN NON-INDIAN’S POPULATION AND LACK OF MINIMUM KNOWLEDGE IN THE INDIAN PUBLIC, PLUS WE COULD DRAW FROM OUR OWN EXPERIENCES, WE UNDERSTAND THAT INDIAN EDUCATION DOESN’T PRESS AND EDUCATE CONSTITUTION DETAILS IN SCHOOL EDUCATION. SO, MY WIFE AND I THOUGHT, WE SHOULD GET AN APP THAT WOULD BE SEARCHBLE AND EASILY ACCESSBLE AT ONE’S DISPOSAL ON THEIR SMARTPHONES. I THINK WE FAIRLY SUCCESSFUL IN IT. CURRENTLY WE MADE THIS APP IN ENGLISH AND TELUGU LANGUAGES AND WE MAY EXTEND THIS IN OTHER LANGUGES (SUCH AS TAMIL, KANNADA, HINDI AND MALAYALAM) BASED ON INTEREST FROM PUBLIC."
        
        self.thirdParagraphLbl.text = "FIRST, LET ME ACKNOWLEDGE AND BE THANKFUL TO NALINI T FOR HELPING AND SUPPORTING ME BOTH FINANCIALLY AND MORALLY TO GET THIS APP INTO REALITY. MY SINCERE GRATITUDE FOR HER SUPPORT."
        
        self.fourthParagraphLbl.text = "I WOULD LIKE TO THANK AJAY MEDIDI AND HARI GOLLAPALLI FOR INTRODUCING ME TO THE AMAZING APP DEVELOPMENT TEAM AND GIVNG ME THEIR VALUEBLE INPUTS AND SUGGESTIONS ALL ALONG. I WOULD LIKE TO THANK MR. M SIVRAM OF M/S. SUWIN SOFTWARE SOLTUTIONS, HYDERABAD FOR KINDLY ACCEPTING OUR REQUEST AND HELPING US TO DEVELOP THIS APP AT A VERY LOW COST IN RESPECT TO OUR INTENTION BEHIND BRINGING THIS APP TO THE PUBLIC AT FREE OF COST WITH ABSOLUTLY NO ADVERTISMENTS."
        
        self.fifthParagraphLbl.text = "I AM SO HAPPY ABOUT THEIR SOFTWARE DEVELOPMENT MODEL AND DECIPLINES FOLLOWED WITH A CLEINT LIKE ME. OUR SINCERE SPECIAL THANKS TO DEVLOPMENT LEAD, MR. SRUJAN SIMHA FOR ALL HIS DEDICATED EFFORTS IN COMPLETING THIS APP WITH A STUNNING QUALITY AS PLANNED."
        
        self.sixthParagraphLbl.text = "PLEASE CONTACT TBD@GMAIL.COM FOR FURTHER ENQUIRES AND FEEDBACKS."
        
        self.thankYouLbl.text = "THANK YOU, \nL.B. DONTUBOYINA"*/
        
        
        /*self.firstParagraphLbl.text = "THE MAIN GOAL OF THIS APP IS TO BRING CONSTITUTIONAL AWARENESS AMONG THE INDIAN PUBLIC."
        
        self.secondParagraphLbl.text = "CURRENTLY WE HAVE DEVELOPED THIS APP IN TWO LANGUAGES, ENGLISH AND TELUGU AND WE MAY EXTEND THIS IN OTHER LANGUAGES (SUCH AS TAMIL, KANNADA, HINDI AND MALAYALAM) IN FUTURE."
        
        self.thirdParagraphLbl.text = "I WOULD LIKE TO THANK AJAY MEDIDI AND HARI GOLLAPALLI FOR INTRODUCING ME TO AN AMAZING APP DEVELOPMENT TEAM AND GIVING ME THEIR VALUABLE INPUTS, SUGGESTIONS ALL ALONG. I WOULD LIKE TO THANK MR. M SIVRAM OF M/S. SUWIN SOFTWARE SOLUTIONS, HYDERABAD FOR KINDLY ACCEPTING OUR REQUEST AND HELPING US TO COMPLETE THIS APP DEVELOPMENT ON A LOW BUDGET TO OUR INTENTION BEHIND BRINGING THIS APP TO THE PUBLIC FOR FREE OF COST."
        
        self.fourthParagraphLbl.text = "OUR SINCERE SPECIAL THANKS TO DEVELOPMENT LEAD, MR. SRUJAN SIMHA FOR ALL HIS DEDICATED EFFORTS IN COMPLETING THIS APP WITH A STUNNING QUALITY AS PLANNED."
        
        self.fifthParagraphLbl.text = "PLEASE CONTACT M/S. SUWIN SOFTWARE SOLUTIONS, HYDERABAD FOR ANY SECURITY AND PRIVACY RELATED ISSUES."
        
        self.sixthParagraphLbl.text = "THANK YOU, \nL.B. DONTUBOYINA"
        
        self.thankYouLbl.isHidden = true
   //     self.thankYouLbl.text = "THANK YOU, \nL.B. DONTUBOYINA"*/
        
        //3-8-22
        self.firstParagraphLbl.text = "THE MAIN GOAL OF THIS APP IS TO BRING CONSTITUTIONAL AWARENESS AMONG THE INDIAN PUBLIC."
        
        self.secondParagraphLbl.text = "CURRENTLY WE HAVE DEVELOPED THIS APP IN TWO LANGUAGES, ENGLISH AND TELUGU AND WE MAY EXTEND THIS IN OTHER LANGUAGES (SUCH AS TAMIL, KANNADA, HINDI AND MALAYALAM) IN FUTURE."
        
        self.thirdParagraphLbl.text = "I WOULD LIKE TO THANK AJAY MEDIDI AND HARI GOLLAPALLI FOR INTRODUCING ME TO AN AMAZING APP DEVELOPMENT TEAM AND GIVING ME THEIR VALUABLE INPUTS, SUGGESTIONS. OUR SINCERE THANKS TO MR. M SIVRAM OF M/S. SUWIN SOFTWARE SOLUTIONS, HYDERABAD FOR SUGGESTING THE TECHNICAL PARTNER."
        
        self.fourthParagraphLbl.text = "I WOULD LIKE TO THANK MR. SRUJAN SIMHA MERUGU OF M/S. WEBINGATE SOLUTIONS PRIVATE LIMITED, HYDERABAD FOR KINDLY ACCEPTING OUR REQUEST AND HELPING US TO COMPLETE THIS APP DEVELOPMENT ON VERY LOW BUDGET."
        
        self.fifthParagraphLbl.text = "PLEASE CONTACT LBDONTUBOYINA@GMAIL.COM FOR FURTHER ENQUIRES AND FEEDBACKS."
        
        self.sixthParagraphLbl.text = "PLEASE CONTACT WEBINGATE@GMAIL.COM FOR ANY TECHNICAL OR SECURITY RELATED ISSUES."
        
   //     self.thankYouLbl.isHidden = true
        self.thankYouLbl.text = "THANK YOU, \nL.B. DONTUBOYINA"
        
        
        
        
        
        
        
        
    }
    
        
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
            
        navigationController?.setNavigationBarHidden(false, animated: animated)
    
    }
    
    @IBAction func ContactPageBackBtnAction(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
//        navigationController?.popToRootViewController(animated: true)
        
    }
    


}

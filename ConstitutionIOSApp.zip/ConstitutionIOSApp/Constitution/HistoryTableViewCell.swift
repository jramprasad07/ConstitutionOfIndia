//
//  HistoryTableViewCell.swift
//  Constitution
//
//  Created by macmini on 13/08/21.
//

import UIKit


protocol HistoryDelegate {
    
    func SearchSelection(indx: Int, selectMode: Int)
    
}


class HistoryTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var searchedSaveValueLbl: UILabel!
    @IBOutlet weak var searchedTextLbl: UILabel!
    @IBOutlet weak var checkBoxBtn: UIButton!
    
    var delegate: HistoryDelegate?
        var index: IndexPath?
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    @IBAction func CheckBoxBtnAction(_ sender: UIButton) {
        
        if sender.isSelected {
            sender.isSelected = false       //Unchecked
            delegate?.SearchSelection(indx: sender.tag, selectMode: 0)
        } else {
            sender.isSelected = true
            delegate?.SearchSelection(indx: sender.tag, selectMode: 1)
            
        }
        
    }
    
    
    

}

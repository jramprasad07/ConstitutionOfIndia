//
//  ViewController.swift
//  Constitution
//
//  Created by macmini on 14/05/21.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var dashboardItemsCollectionView: UICollectionView!
    @IBOutlet weak var englishRBtn: UIButton!
    @IBOutlet weak var teluguRBtn: UIButton!
    @IBOutlet weak var hindiRBtn: UIButton!
    @IBOutlet weak var tamilRBtn: UIButton!
    @IBOutlet weak var malayalamRBtn: UIButton!
    @IBOutlet weak var kannadaRBtn: UIButton!
    
    
    
    let radioController: RadioButtonController = RadioButtonController()
    
    
    var itemImages = [UIImage(named: "full_text"), UIImage(named: "search_tab"), UIImage(named: "history"), UIImage(named: "share_black"), UIImage(named: "user_tab_new"), UIImage(named: "information")]
    var itemNames = ["Full text", "Search", "Saved Searches", "Share", "Contact", "History"]
    var itemNamesTelugu = ["పూర్తి వచనం", "శోధన", "సేవ్ చేసిన శోధనలు", "షేర్", "సంప్రదించండి", "చరిత్ర"]
    
    var selectedLanguage = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.// 184, 221, 242 //190, 228, 250//
        
        if #available(iOS 13.0, *) {
            let statusBar = UIView(frame: UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame ?? CGRect.zero)
            
            statusBar.backgroundColor = UIColor.init(red: 56.0/255.0, green: 118.0/255.0, blue: 242.0/255.0, alpha: 1.0)
            
            UIApplication.shared.keyWindow?.addSubview(statusBar)
        } else {
            UIApplication.shared.statusBarView?.backgroundColor = UIColor.init(red: 56.0/255.0, green: 118.0/255.0, blue: 242.0/255.0, alpha: 1.0)
        }
        
        
        ViewInitialisation()
        
        
        
        
    }
    
    func ViewInitialisation() {
        
        radioController.buttonsArray = [englishRBtn, teluguRBtn, hindiRBtn, tamilRBtn, malayalamRBtn, kannadaRBtn]
        
        self.selectedLanguage = UserDefaults.standard.value(forKey: "Language") as? String ?? "0"
        
        if (self.selectedLanguage == "0") {
            radioController.defaultButton = englishRBtn
        } else if(self.selectedLanguage == "1") {
            radioController.defaultButton = teluguRBtn
        }
        //        else if(self.selectedLanguage == "2") {
        //            radioController.defaultButton = hindiRBtn
        //        } else if(self.selectedLanguage == "3") {
        //            radioController.defaultButton = tamilRBtn
        //        } else if(self.selectedLanguage == "4") {
        //            radioController.defaultButton = malayalamRBtn
        //        } else if(self.selectedLanguage == "5") {
        //            radioController.defaultButton = kannadaRBtn
        //        }
        else {
            radioController.defaultButton = englishRBtn
        }
        
        self.dashboardItemsCollectionView.reloadData()
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(true, animated: animated)
        
        ViewInitialisation()
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        //     navigationController?.setNavigationBarHidden(false, animated: animated)
        
    }
    
    
    @IBAction func EnglishRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        UserDefaults.standard.setValue("0", forKey: "Language")
        self.toastMessage("You selected English language")
        ViewInitialisation()
    }
    
    @IBAction func TeluguRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        UserDefaults.standard.setValue("1", forKey: "Language")
        self.toastMessage("మీరు తెలుగు భాషను ఎంచుకున్నారు")
        ViewInitialisation()
        
    }
    
    @IBAction func HindiRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        //        UserDefaults.standard.setValue("2", forKey: "Language")
        //      ViewInitialisation()
        self.toastMessage("कॉन्फ़िगर नहीं किया गया हिंदी भाषा")
    }
    
    @IBAction func TamilRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        //     UserDefaults.standard.setValue("3", forKey: "Language")
        //        ViewInitialisation()
        self.toastMessage("தமிழ் மொழியை உள்ளமைக்கவில்லை")
    }
    
    @IBAction func MalayalamRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        //    UserDefaults.standard.setValue("4", forKey: "Language")
        //        ViewInitialisation()
        self.toastMessage("മലയാള ഭാഷ ക്രമീകരിച്ചിട്ടില്ല")
    }
    
    @IBAction func KannadaRBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        //       UserDefaults.standard.setValue("5", forKey: "Language")
        //        ViewInitialisation()
        self.toastMessage("ಕನ್ನಡ ಭಾಷೆಯನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡಿಲ್ಲ")
    }
    
}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemNames.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if (collectionView == dashboardItemsCollectionView) {
            
            let itemsCell = dashboardItemsCollectionView.dequeueReusableCell(withReuseIdentifier: "DashboardItemsCollectionViewCell", for: indexPath) as? DashboardItemsCollectionViewCell
            
            if self.itemNames.count > 0 {
                
                itemsCell?.dashboardItemsImageView.image = self.itemImages[indexPath.row]
                
                itemsCell?.dashboardItemsImageView.image = itemsCell?.dashboardItemsImageView.image?.withRenderingMode(.alwaysTemplate)
                itemsCell?.dashboardItemsImageView.tintColor = UIColor.systemBlue
                
                if (self.selectedLanguage == "0") {
                    itemsCell?.dashboardItemsNameLbl.text = self.itemNames[indexPath.row]
                    itemsCell?.dashboardItemsNameLbl.textColor = UIColor.systemBlue
                    itemsCell?.dashboardItemsNameLbl.numberOfLines = 2
                } else if(self.selectedLanguage == "1") {
                    itemsCell?.dashboardItemsNameLbl.text = self.itemNamesTelugu[indexPath.row]
                    itemsCell?.dashboardItemsNameLbl.textColor = UIColor.systemBlue
                    itemsCell?.dashboardItemsNameLbl.numberOfLines = 2
                }
                
            }
            
            return itemsCell!
            
        }
        return UICollectionViewCell()
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        if (collectionView == dashboardItemsCollectionView) {
            
            if (indexPath.row == 0) {
                
                let homeVC = storyboard?.instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
                self.navigationController?.pushViewController(homeVC, animated: true)
                
            } else if (indexPath.row == 1) {
                
                UserDefaults.standard.setValue("", forKey: "searchTextFromHistory")
                let searchVC = storyboard?.instantiateViewController(withIdentifier: "SearchNewViewController") as! SearchNewViewController
                self.navigationController?.pushViewController(searchVC, animated: true)
                
            } else if (indexPath.row == 2) {
                
                let searchVC = storyboard?.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
                self.navigationController?.pushViewController(searchVC, animated: true)
                
            } else if (indexPath.row == 3) {
                
                // text to share
                let text = "Let me recommend you this application \n\n (App download link...)"
                
                // set up activity view controller
                let textToShare = [ text ]
                let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
                activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
                
                // exclude some activity types from the list (optional)
                activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
                
                // present the view controller
                self.present(activityViewController, animated: true, completion: nil)
                
            } else if (indexPath.row == 4) {
                
                let searchVC = storyboard?.instantiateViewController(withIdentifier: "ContactViewController") as! ContactViewController
                self.navigationController?.pushViewController(searchVC, animated: true)
                
                
                //                    let homeVC = storyboard?.instantiateViewController(withIdentifier: "TableViewController") as! TableViewController
                //                    self.navigationController?.pushViewController(homeVC, animated: true)
                
                
            } else if (indexPath.row == 5) {
                
                let searchVC = storyboard?.instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
                self.navigationController?.pushViewController(searchVC, animated: true)
                
            }
            
        }
        
    }
    
}

extension UIApplication {
    
    var statusBarView: UIView? {
        return value(forKey: "statusBar") as? UIView
    }
    
}


//Extention Functions
extension UIViewController {
    
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action:    #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func NoInterNetAlertDialog() {
        let connectivityAlert = UIAlertController(title: "No Internet", message: "Please check your Internet Connection and try again!!", preferredStyle: UIAlertController.Style.alert)
        connectivityAlert.addAction(UIAlertAction(title: "Try Again",style: UIAlertAction.Style.default, handler: nil))
        self.present(connectivityAlert, animated: true, completion: nil)
    }
    
    
    func toastMessage(_ message: String) {
        guard let window = UIApplication.shared.keyWindow else {return}
        let messageLbl = UILabel()
        messageLbl.text = message
        messageLbl.textAlignment = .center
        messageLbl.font = UIFont.systemFont(ofSize: 16)
        messageLbl.textColor = .white
        messageLbl.backgroundColor = UIColor(white: 0, alpha: 0.5)
        messageLbl.clipsToBounds = true
        messageLbl.numberOfLines = 0
        
        let textSize:CGSize = messageLbl.intrinsicContentSize
        let labelWidth = min(textSize.width, window.frame.width - 40)
        
        messageLbl.frame = CGRect(x: 20, y: window.frame.height - 200, width: labelWidth + 30, height: textSize.height + 28)
        messageLbl.center.x = window.center.x
        messageLbl.layer.cornerRadius = messageLbl.frame.height/2
        messageLbl.layer.masksToBounds = true
        window.addSubview(messageLbl)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
            UIView.animate(withDuration: 3, animations: {
                messageLbl.alpha = 0
            }) { (_) in
                messageLbl.removeFromSuperview()
            }
        }
    }
    
    
    
}




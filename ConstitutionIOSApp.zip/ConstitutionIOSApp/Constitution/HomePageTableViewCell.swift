//
//  HomePageTableViewCell.swift
//  Constitution
//
//  Created by macmini on 17/05/21.
//

import UIKit
import SwiftyXMLParser

class HomePageTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var homePageItemNameLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var indexLbl: UILabel!
    
    var currId = "0"
    var patharray: [XMLSubscriptType] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

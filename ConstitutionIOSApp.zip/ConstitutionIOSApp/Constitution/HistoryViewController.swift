//
//  HistoryViewController.swift
//  Constitution
//
//  Created by macmini on 15/05/21.
//

import UIKit

class HistoryViewController: UIViewController {


    @IBOutlet weak var historyPageBackBtn: UIButton!
    @IBOutlet weak var historyTableView: UITableView!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var selectAllBtn: UIButton!
    
    
    var savedSearchText: [SearchedTextJson] = []
    var savedValue = String()
    var searchedText = String()
    var name = String()
    
    var isSelectAll = false; //global variable
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        self.historyTableView.delegate = self
        self.historyTableView.dataSource = self
        
        self.historyPageBackBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        self.deleteBtn.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        self.selectAllBtn.setTitle("Select All", for: .normal)
        
        
        // Read/Get Data
        if let data = UserDefaults.standard.data(forKey: "savedSearch") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()
                // Decode Note
                savedSearchText = try decoder.decode([SearchedTextJson].self, from: data)
                print("--40--**--saved search array---**--:: \(savedSearchText)")
                
                for items in 0..<savedSearchText.count {
                    self.savedValue = self.savedSearchText[items].savedValue
                    self.searchedText = self.savedSearchText[items].searchedText
                    print("--44---saved value -- -- \(self.savedValue)")
                    print("--45---searched text -- -- \(self.searchedText)")
                    
                }
                
            } catch {
                print("Unable to Decode Note (\(error))")
            }
        } else {
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            
        navigationController?.setNavigationBarHidden(true, animated: animated)
        self.tabBarController?.tabBar.isHidden = false
            
  //      ViewInitialisation()
        
        self.historyTableView.reloadData()
            
    }
        
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
            
        navigationController?.setNavigationBarHidden(false, animated: animated)
    
    }
    
    @IBAction func HistoryPageBackBtnAction(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
//        navigationController?.popToRootViewController(animated: true)
        
    }
    
    @IBAction func DeleteBtnAction(_ sender: Any) {
        
        
        if(self.savedSearchText.count > 0){
            
            let alert = UIAlertController(title: "Delete alert!", message: "Are you sure you want to delete?", preferredStyle: UIAlertController.Style.alert)
            let actionNo = UIAlertAction(title: "No", style: .default) { (action) -> Void in
                
            }
            let actionYes = UIAlertAction(title: "Yes", style: .default) { (action) -> Void in
                
                if self.selectAllBtn.titleLabel?.text == "Deselect All" {
                    
                    self.savedSearchText.removeAll()
                    UserDefaults.standard.set(nil, forKey: "savedSearch")
                
                    self.selectAllBtn.setTitle("Select All", for: .normal)
                    
                } else {
                    
      //              self.selectAllBtn.setTitle("Deselect All", for: .normal)
                   
                    self.savedSearchText = self.savedSearchText.filter(){$0.isSelected == 0}
                    
                    do {
                        // Create JSON Encoder
                        let encoder = JSONEncoder()
                        // Encode Note
                        let data = try encoder.encode(self.savedSearchText)
                        // Write/Set Data
                        UserDefaults.standard.set(data, forKey: "savedSearch")
                    } catch {
                        print("Unable to Encode Note (\(error))")
                    }
                }
                
                self.historyTableView.reloadData()
                
            }
            
            alert.addAction(actionNo)
            alert.addAction(actionYes)
            self.present(alert, animated: true, completion: nil)
            return
            
        } else {
            
            self.toastMessage("No items to delete")
            
        }
        
        
    }
    
    @IBAction func SelectAllBtnAction(_ sender: Any) {
        
        if(self.savedSearchText.count > 0){
            
            if self.selectAllBtn.titleLabel?.text == "Select All" {
                
                isSelectAll = true
                self.historyTableView.reloadData()
                
                self.selectAllBtn.setTitle("Deselect All", for: .normal)
                
            } else {
                
                isSelectAll = false
                self.historyTableView.reloadData()
                
                self.selectAllBtn.setTitle("Select All", for: .normal)
                
            }
            
        } else {
            self.toastMessage("No items to select")
        }
        
        
    }
    

}


extension HistoryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return savedSearchText.count

    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (tableView == historyTableView) {
                    
            let historyCell = tableView.dequeueReusableCell(withIdentifier: "HistoryTableViewCell", for: indexPath) as? HistoryTableViewCell
            
            historyCell?.searchedSaveValueLbl.text = savedSearchText[indexPath.row].savedValue
            historyCell?.searchedSaveValueLbl.numberOfLines = 1
            historyCell?.searchedTextLbl.text = savedSearchText[indexPath.row].searchedText
            historyCell?.searchedTextLbl.numberOfLines = 1
            
            historyCell?.checkBoxBtn.tag = indexPath.row
            
            historyCell?.index = indexPath
            historyCell?.delegate = self
            
            if(isSelectAll == true) {
                historyCell?.checkBoxBtn.isSelected = true
                savedSearchText[indexPath.row].isSelected = 1
            } else {
                historyCell?.checkBoxBtn.isSelected = false
                savedSearchText[indexPath.row].isSelected = 0
            }
            
            return historyCell!
            
        }
        
        return UITableViewCell()
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
        if (tableView == historyTableView) {
            
            var text = savedSearchText[indexPath.row].searchedText
            
            UserDefaults.standard.setValue(text, forKey: "searchTextFromHistory")
            
            let searchVC = storyboard?.instantiateViewController(withIdentifier: "SearchNewViewController") as! SearchNewViewController
            self.navigationController?.pushViewController(searchVC, animated: true)
        
        }
        
    }
    
    
}


extension HistoryViewController: HistoryDelegate {
    
    func SearchSelection(indx: Int, selectMode: Int) {
        
        var itemscount = savedSearchText.count
        print("****--itemscount---**-------:: \(itemscount)")
        
       savedSearchText[indx].isSelected = selectMode
      
        
    }

}





//
//  DashboardItemsCollectionViewCell.swift
//  Constitution
//
//  Created by macmini on 14/05/21.
//

import UIKit

class DashboardItemsCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var dashboardItemsImageView: UIImageView!
    @IBOutlet weak var dashboardItemsNameLbl: UILabel!
    
    
//    override func layoutSubviews() {
//        super.layoutSubviews()

//    }
    

    
    
}
